package com.motionstudio.ai

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.coroutines.delay
import java.util.zip.ZipInputStream
import org.xmlpull.v1.XmlPullParser
import android.util.Xml

private data class MediaAsset(val uri: Uri, val name: String, val mime: String, val kind: AssetKind)
private enum class AssetKind { VIDEO, AUDIO, IMAGE, SUBTITLE, TEXT, DOCUMENT, OTHER }
private data class SubtitleCue(val startMs: Long, val endMs: Long, val text: String)

class MainActivity : ComponentActivity() {
    @OptIn(UnstableApi::class)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme { MotionStudioApp() } }
    }
}

@OptIn(ExperimentalMaterial3Api::class, UnstableApi::class)
@Composable
private fun MotionStudioApp() {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var assets by remember { mutableStateOf(emptyList<MediaAsset>()) }
    var selectedVideo by remember { mutableStateOf<Uri?>(null) }
    var selectedAudio by remember { mutableStateOf<Uri?>(null) }
    var selectedSubtitle by remember { mutableStateOf<Uri?>(null) }
    var cues by remember { mutableStateOf(emptyList<SubtitleCue>()) }
    var textTitle by remember { mutableStateOf("") }
    var textBody by remember { mutableStateOf("") }
    var showTextDialog by remember { mutableStateOf(false) }
    var status by remember { mutableStateOf("Ready — import files to begin") }
    var exportPreset by remember { mutableStateOf("1080p") }
    var exportFps by remember { mutableStateOf("30 fps") }
    var exportDialog by remember { mutableStateOf(false) }
    var showSubtitlePanel by remember { mutableStateOf(false) }
    var currentPosition by remember { mutableLongStateOf(0L) }
    var duration by remember { mutableLongStateOf(0L) }

    val player = remember { ExoPlayer.Builder(context).build() }
    LaunchedEffect(player) {
        while (true) { currentPosition = player.currentPosition.coerceAtLeast(0); duration = player.duration.coerceAtLeast(0); delay(300) }
    }
    DisposableEffect(player) {
        val listener = object : Player.Listener {
            override fun onIsPlayingChanged(isPlaying: Boolean) { }
            override fun onPlaybackStateChanged(playbackState: Int) {
                if (playbackState == Player.STATE_READY) duration = player.duration.coerceAtLeast(0)
            }
        }
        player.addListener(listener)
        onDispose { player.removeListener(listener); player.release() }
    }
    val lifecycleOwner = LocalLifecycleOwner.current
    DisposableEffect(player, lifecycleOwner) {
        val obs = LifecycleEventObserver { _, e -> if (e == Lifecycle.Event.ON_PAUSE) player.pause() }
        lifecycleOwner.lifecycle.addObserver(obs)
        onDispose { lifecycleOwner.lifecycle.removeObserver(obs) }
    }

    val importPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        if (uris.isNotEmpty()) {
            uris.forEach { uri -> runCatching { context.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) } }
            val newAssets = uris.map { uri ->
                val mime = context.contentResolver.getType(uri) ?: "application/octet-stream"
                val name = queryDisplayName(context, uri) ?: uri.lastPathSegment?.substringAfterLast('/') ?: "Imported file"
                MediaAsset(uri, name, mime, classify(name, mime))
            }
            assets = assets + newAssets
            newAssets.firstOrNull { it.kind == AssetKind.VIDEO }?.let { if (selectedVideo == null) openVideo(it.uri) }
            newAssets.firstOrNull { it.kind == AssetKind.AUDIO }?.let { if (selectedAudio == null) selectedAudio = it.uri }
            newAssets.firstOrNull { it.kind == AssetKind.SUBTITLE }?.let { subtitle ->
                selectedSubtitle = subtitle.uri
                scope.launch {
                    status = "Reading subtitles: ${subtitle.name}"
                    val parsed = withContext(Dispatchers.IO) { readSubtitle(context, subtitle.uri) }
                    cues = parsed
                    status = "Loaded ${parsed.size} subtitle cues"
                }
            }
            newAssets.firstOrNull { it.kind == AssetKind.TEXT || it.kind == AssetKind.DOCUMENT }?.let { file ->
                scope.launch {
                    val content = withContext(Dispatchers.IO) { runCatching { readTextFile(context, file.uri, file.name) }.getOrElse { "Unable to read file: ${it.message}" } }
                    textTitle = file.name
                    textBody = content
                    showTextDialog = true
                    status = "Text opened: ${file.name}"
                }
            }
            status = "Imported ${newAssets.size} file(s)"
        }
    }

    fun openVideo(uri: Uri) {
        selectedVideo = uri
        player.setMediaItem(MediaItem.fromUri(uri)); player.prepare(); player.playWhenReady = false
        status = "Video selected — ready to preview"
    }

    Scaffold(
        topBar = {
            TopAppBar(title = { Text("Motion Studio AI") }, actions = {
                IconButton(onClick = { importPicker.launch(arrayOf("video/*", "audio/*", "image/*", "text/*", "application/x-subrip", "application/vnd.openxmlformats-officedocument.wordprocessingml.document")) }) {
                    Icon(Icons.Default.Add, "Import files")
                }
            })
        },
        bottomBar = {
            NavigationBar {
                NavigationBarItem(selected = true, onClick = { }, icon = { Text("🎬") }, label = { Text("Editor") })
                NavigationBarItem(selected = false, onClick = { showSubtitlePanel = !showSubtitlePanel }, icon = { Text("CC") }, label = { Text("Subtitles") })
                NavigationBarItem(selected = false, onClick = { exportDialog = true }, icon = { Text("⇧") }, label = { Text("Export") })
            }
        }
    ) { padding ->
        Column(Modifier.fillMaxSize().padding(padding).padding(horizontal = 12.dp, vertical = 8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("Offline editing workspace", style = MaterialTheme.typography.titleMedium)
            Text(status, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.primary)

            if (selectedVideo != null) {
                AndroidView(factory = { ctx -> PlayerView(ctx).apply { this.player = player } }, modifier = Modifier.fillMaxWidth().height(210.dp))
            } else {
                Surface(Modifier.fillMaxWidth().height(190.dp), color = MaterialTheme.colorScheme.surfaceVariant) {
                    Box(contentAlignment = Alignment.Center) { Text("Import a video to preview") }
                }
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly, verticalAlignment = Alignment.CenterVertically) {
                TextButton(onClick = { player.seekTo((player.currentPosition - 10_000).coerceAtLeast(0)) }, enabled = selectedVideo != null) { Text("−10s") }
                IconButton(onClick = { if (player.isPlaying) player.pause() else player.play() }, enabled = selectedVideo != null) {
                    Text(if (player.isPlaying) "Ⅱ" else "▶", style = MaterialTheme.typography.headlineMedium)
                }
                TextButton(onClick = { player.seekTo((player.currentPosition + 10_000).coerceAtMost(player.duration.coerceAtLeast(0))) }, enabled = selectedVideo != null) { Text("+10s") }
            }
            if (selectedVideo != null) {
                val sliderValue = if (duration > 0) (currentPosition.toFloat() / duration).coerceIn(0f, 1f) else 0f
                Slider(value = sliderValue, onValueChange = { v -> if (duration > 0) player.seekTo((duration * v).toLong()) })
                Text("${formatMs(player.currentPosition)} / ${formatMs(player.duration.coerceAtLeast(0))}", style = MaterialTheme.typography.labelSmall)
            }

            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                listOf("720p", "1080p", "4K").forEach { p -> FilterChip(selected = exportPreset == p, onClick = { exportPreset = p }, label = { Text(p) }) }
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Timeline & imported media", style = MaterialTheme.typography.titleSmall, modifier = Modifier.weight(1f))
                TextButton(onClick = { importPicker.launch(arrayOf("video/*", "audio/*", "image/*", "text/*", "application/x-subrip", "application/vnd.openxmlformats-officedocument.wordprocessingml.document")) }) { Text("Add files") }
            }
            if (assets.isEmpty()) {
                Text("No media imported yet. Use + to add video, voice, music, images, SRT, TXT or DOCX.", style = MaterialTheme.typography.bodySmall)
            } else {
                LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                    itemsIndexed(assets, key = { index, item -> "${item.uri}-$index" }) { _, asset ->
                        ListItem(
                            leadingContent = { Text(emojiFor(asset.kind), style = MaterialTheme.typography.titleLarge) },
                            headlineContent = { Text(asset.name, maxLines = 1) },
                            supportingContent = { Text(asset.kind.name.lowercase().replaceFirstChar { it.uppercase() } + " • " + asset.mime, maxLines = 1) },
                            trailingContent = {
                                Row {
                                    when (asset.kind) {
                                        AssetKind.VIDEO -> TextButton(onClick = { openVideo(asset.uri) }) { Text(if (selectedVideo == asset.uri) "Selected" else "Preview") }
                                        AssetKind.AUDIO -> TextButton(onClick = { selectedAudio = asset.uri; status = "Audio selected: ${asset.name}" }) { Text(if (selectedAudio == asset.uri) "Selected" else "Use") }
                                        AssetKind.SUBTITLE -> TextButton(onClick = { selectedSubtitle = asset.uri; scope.launch { cues = withContext(Dispatchers.IO) { readSubtitle(context, asset.uri) }; showSubtitlePanel = true; status = "Subtitle loaded: ${cues.size} cues" } }) { Text("View") }
                                        AssetKind.TEXT, AssetKind.DOCUMENT -> TextButton(onClick = { scope.launch { textTitle = asset.name; textBody = withContext(Dispatchers.IO) { readTextFile(context, asset.uri, asset.name) }; showTextDialog = true } }) { Text("Open") }
                                        else -> TextButton(onClick = { status = "Selected: ${asset.name}" }) { Text("Use") }
                                    }
                                    IconButton(onClick = { assets = assets.filterNot { it.uri == asset.uri }; if (selectedVideo == asset.uri) { selectedVideo = null; player.stop() }; if (selectedAudio == asset.uri) selectedAudio = null; if (selectedSubtitle == asset.uri) { selectedSubtitle = null; cues = emptyList() }; status = "Removed ${asset.name}" }) { Text("✕") }
                                }
                            }
                        )
                    }
                }
            }
            if (showSubtitlePanel) {
                Text("Subtitle cues: ${cues.size}", style = MaterialTheme.typography.titleSmall)
                LazyColumn(Modifier.heightIn(max = 180.dp)) {
                    items(cues) { cue ->
                        ListItem(headlineContent = { Text("${formatMs(cue.startMs)} → ${formatMs(cue.endMs)}") }, supportingContent = { Text(cue.text) })
                    }
                }
            }
            if (selectedAudio != null) Text("Audio selected: ${assets.firstOrNull { it.uri == selectedAudio }?.name ?: "audio"}", style = MaterialTheme.typography.bodySmall)
            Button(onClick = { exportDialog = true }, modifier = Modifier.fillMaxWidth(), enabled = selectedVideo != null) { Text("Export settings") }
        }
    }

    if (showTextDialog) AlertDialog(onDismissRequest = { showTextDialog = false }, title = { Text(textTitle) }, text = { LazyColumn(Modifier.heightIn(max = 500.dp)) { item { Text(textBody) } } }, confirmButton = { TextButton(onClick = { showTextDialog = false }) { Text("Close") } })
    if (exportDialog) AlertDialog(
        onDismissRequest = { exportDialog = false }, title = { Text("Export settings") },
        text = { Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("Resolution: $exportPreset")
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) { listOf("24 fps", "30 fps", "60 fps").forEach { FilterChip(selected = exportFps == it, onClick = { exportFps = it }, label = { Text(it) }) } }
            Text("Export/render engine is not connected in this build. These settings are saved in the UI only.")
        } },
        confirmButton = { TextButton(onClick = { exportDialog = false; Toast.makeText(context, "Render engine not connected yet", Toast.LENGTH_LONG).show(); status = "Export engine required — no video rendered" }) { Text("OK") } },
        dismissButton = { TextButton(onClick = { exportDialog = false }) { Text("Cancel") } }
    )
}


private fun emojiFor(kind: AssetKind) = when (kind) {
    AssetKind.VIDEO -> "🎬"
    AssetKind.AUDIO -> "🎵"
    AssetKind.SUBTITLE -> "💬"
    AssetKind.TEXT, AssetKind.DOCUMENT -> "📄"
    AssetKind.IMAGE -> "🖼️"
    else -> "📁"
}

private fun classify(name: String, mime: String): AssetKind {
    val n = name.lowercase()
    return when {
        mime.startsWith("video/") -> AssetKind.VIDEO
        mime.startsWith("audio/") -> AssetKind.AUDIO
        mime.startsWith("image/") -> AssetKind.IMAGE
        n.endsWith(".srt") || n.endsWith(".vtt") || mime == "application/x-subrip" -> AssetKind.SUBTITLE
        n.endsWith(".txt") || mime.startsWith("text/") -> AssetKind.TEXT
        n.endsWith(".docx") -> AssetKind.DOCUMENT
        else -> AssetKind.OTHER
    }
}

private fun queryDisplayName(context: android.content.Context, uri: Uri): String? {
    return runCatching {
        context.contentResolver.query(uri, arrayOf(android.provider.OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
            if (c.moveToFirst()) c.getString(c.getColumnIndexOrThrow(android.provider.OpenableColumns.DISPLAY_NAME)) else null
        }
    }.getOrNull()
}

private fun readSubtitle(context: android.content.Context, uri: Uri): List<SubtitleCue> {
    val raw = context.contentResolver.openInputStream(uri)?.bufferedReader(Charsets.UTF_8)?.use { it.readText() } ?: return emptyList()
    val blocks = raw.replace("\r", "").split(Regex("\\n\\s*\\n"))
    return blocks.mapNotNull { block ->
        val lines = block.lines().map { it.trim() }.filter { it.isNotEmpty() }
        val timeLine = lines.firstOrNull { it.contains("-->") } ?: return@mapNotNull null
        val parts = timeLine.split("-->")
        if (parts.size < 2) return@mapNotNull null
        val start = parseTimestamp(parts[0].trim()) ?: return@mapNotNull null
        val end = parseTimestamp(parts[1].trim().substringBefore(' ')) ?: return@mapNotNull null
        val text = lines.dropWhile { it != timeLine }.drop(1).joinToString("\n")
        if (text.isBlank()) null else SubtitleCue(start, end, text)
    }
}

private fun parseTimestamp(s: String): Long? {
    val clean = s.replace(',', '.').trim()
    val p = clean.split(":")
    return runCatching {
        when (p.size) {
            3 -> ((p[0].toLong() * 3600 + p[1].toLong() * 60) * 1000) + (p[2].toDouble() * 1000).toLong()
            2 -> ((p[0].toLong() * 60 + p[1].toDouble()) * 1000).toLong()
            else -> null
        }
    }.getOrNull()
}

private fun formatMs(ms: Long): String {
    val safe = ms.coerceAtLeast(0)
    val h = safe / 3_600_000
    val m = (safe / 60_000) % 60
    val s = (safe / 1000) % 60
    return if (h > 0) "%02d:%02d:%02d".format(h, m, s) else "%02d:%02d".format(m, s)
}

private fun readTextFile(context: android.content.Context, uri: Uri, filename: String): String {
    if (filename.lowercase().endsWith(".docx")) {
        context.contentResolver.openInputStream(uri).use { input ->
            requireNotNull(input) { "File stream unavailable" }
            ZipInputStream(input).use { zip ->
                var entry = zip.nextEntry
                while (entry != null) {
                    if (entry.name == "word/document.xml") {
                        val xml = zip.readBytes().toString(Charsets.UTF_8)
                        val parser = Xml.newPullParser().apply { setInput(xml.reader()) }
                        val output = StringBuilder()
                        var event = parser.eventType
                        while (event != XmlPullParser.END_DOCUMENT) {
                            if (event == XmlPullParser.START_TAG && parser.name == "t") output.append(parser.nextText())
                            if (event == XmlPullParser.END_TAG && parser.name == "p") output.append('\n')
                            event = parser.eventType
                            if (event != XmlPullParser.END_DOCUMENT) event = parser.next()
                        }
                        return output.toString()
                    }
                    zip.closeEntry(); entry = zip.nextEntry
                }
            }
        }
        return "DOCX document text not found"
    }
    return context.contentResolver.openInputStream(uri)?.bufferedReader(Charsets.UTF_8)?.use { it.readText() } ?: ""
}
