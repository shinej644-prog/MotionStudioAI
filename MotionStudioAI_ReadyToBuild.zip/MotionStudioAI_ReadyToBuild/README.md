# MotionStudioAI — Android project

This is the current project bundle assembled from the earlier starter project and the latest `MainActivity.kt` update.

## Current implemented features
- Multi-file media import via Android file picker (video, audio, image, subtitle, text, DOCX)
- Video preview using Media3 ExoPlayer
- Playback, seek slider, and +/-10 second controls
- Imported file list, selection, and removal
- SRT/VTT cue parsing and subtitle cue list
- TXT and basic DOCX text reading
- Export resolution/FPS settings UI

## Not implemented yet
This is **not yet a complete editor or renderer**. Timeline trim/split, clip arrangement, audio mixing, motion graphics, subtitle burn-in, and actual MP4 rendering/export still need implementation. Export dialog currently only displays settings.

## Build APK with GitHub Actions
1. Upload/extract this project so the repository contains the project files at its root (not just the ZIP archive).
2. On GitHub open **Actions** → **Build Android APK** → **Run workflow**.
3. Wait for the build to finish. Open the completed workflow run and download the `MotionStudioAI-debug-apk` artifact.

Build configuration uses Android Gradle Plugin 8.7.3, Gradle 8.9, Kotlin 2.0.21, compile SDK 35, and JDK 17.

The source has not yet been compiled in this environment because Android SDK/Gradle are unavailable here. Treat the first GitHub build as a compile test and address any errors before proceeding.
