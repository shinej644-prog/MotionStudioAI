package com.motionstudio.ai

import android.net.Uri
import android.os.Bundle
import android.content.Intent
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material.icons.filled.Description
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.platform.LocalContext
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.media3.common.util.UnstableApi
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.util.zip.ZipInputStream
import org.xmlpull.v1.XmlPullParser
import android.util.Xml

 data class Asset(val uri: Uri, val name: String, val mime: String)

class MainActivity : ComponentActivity() {
    @OptIn(UnstableApi::class, ExperimentalMaterial3Api::class)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MotionStudioScreen() }
    }
}

@OptIn(UnstableApi::class, ExperimentalMaterial3Api::class)
@Composable
fun MotionStudioScreen() {
    val context = LocalContext.current
    var assets by remember { mutableStateOf(listOf<Asset>()) }
    var selectedVideo by remember { mutableStateOf<Uri?>(null) }
    var textContent by remember { mutableStateOf("") }
    var textTitle by remember { mutableStateOf("") }
    var showText by remember { mutableStateOf(false) }
    var selectedExport by remember { mutableStateOf("1080p") }
    var status by remember { mutableStateOf("Ready — import media to begin") }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        uris.forEach { uri ->
            val mime = context.contentResolver.getType(uri) ?: "application/octet-stream"
            val name = uri.lastPathSegment?.substringAfterLast('/') ?: "Imported file"
            runCatching { context.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) }
            assets = assets + Asset(uri, name, mime)
            if (mime.startsWith("video/") && selectedVideo == null) selectedVideo = uri
            val lower = name.lowercase()
            if (lower.endsWith(".srt") || lower.endsWith(".txt") || mime == "text/plain" || lower.endsWith(".docx")) {
                val parsed = runCatching { readTextAsset(context.contentResolver, uri, lower) }.getOrElse { "Could not read file: ${it.message}" }
                textContent = parsed
                textTitle = name
                status = "Text asset loaded: $name"
                showText = true
            }
        }
    }

    Scaffold(topBar = {
        TopAppBar(title = { Text("Motion Studio AI") }, actions = {
            IconButton(onClick = { picker.launch(arrayOf("video/*", "audio/*", "image/*", "text/*", "application/vnd.openxmlformats-officedocument.wordprocessingml.document")) }) {
                Icon(Icons.Default.Add, contentDescription = "Import files")
            }
        })
    }) { padding ->
        Column(Modifier.fillMaxSize().padding(padding).padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text("Offline-first editing workspace", style = MaterialTheme.typography.titleMedium)
            Text("Import video, voice, music, images, SRT, TXT or DOCX. Files stay on your device unless you choose to share them.", style = MaterialTheme.typography.bodyMedium)
            selectedVideo?.let { VideoPreview(it) } ?: Box(Modifier.fillMaxWidth().height(180.dp), contentAlignment = Alignment.Center) {
                Surface(Modifier.fillMaxWidth().height(180.dp), color = MaterialTheme.colorScheme.surfaceVariant) {
                    Box(contentAlignment = Alignment.Center) { Text("Select a video to preview") }
                }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                listOf("480p", "720p", "1080p").forEach { preset ->
                    FilterChip(selected = selectedExport == preset, onClick = { selectedExport = preset }, label = { Text(preset) })
                }
            }
            Text("Export target: $selectedExport (export engine not yet connected)", style = MaterialTheme.typography.bodySmall)
            Text(status, style = MaterialTheme.typography.bodySmall)
            Text("Project files (${assets.size})", style = MaterialTheme.typography.titleSmall)
            LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                items(assets) { asset ->
                    ListItem(
                        leadingContent = { Icon(if (asset.mime.startsWith("video/")) Icons.Default.Movie else Icons.Default.Description, contentDescription = null) },
                        headlineContent = { Text(asset.name, maxLines = 1) },
                        supportingContent = { Text(asset.mime, maxLines = 1) },
                        trailingContent = { if (asset.name.lowercase().endsWith(".srt") || asset.name.lowercase().endsWith(".txt") || asset.name.lowercase().endsWith(".docx")) TextButton(onClick = { showText = true }) { Text("View") } }
                    )
                }
            }
            Button(onClick = { status = "Review/export module is the next development stage" }, modifier = Modifier.fillMaxWidth(), enabled = selectedVideo != null) {
                Text("Review & Export — coming next")
            }
        }
    }
    if (showText && textContent.isNotEmpty()) {
        AlertDialog(onDismissRequest = { showText = false }, title = { Text(textTitle.ifBlank { "Imported text" }) },
            text = { Box(Modifier.heightIn(max = 420.dp)) { LazyColumn { item { Text(textContent) } } } },
            confirmButton = { TextButton(onClick = { showText = false }) { Text("Close") } })
    }
}

private fun readTextAsset(resolver: android.content.ContentResolver, uri: Uri, filename: String): String {
    if (filename.endsWith(".docx")) {
        resolver.openInputStream(uri).use { input ->
            requireNotNull(input) { "File stream unavailable" }
            ZipInputStream(input).use { zip ->
                var entry = zip.nextEntry
                while (entry != null) {
                    if (entry.name == "word/document.xml") {
                        val xml = zip.readBytes().toString(Charsets.UTF_8)
                        val parser = Xml.newPullParser()
                        parser.setInput(xml.reader())
                        val out = StringBuilder()
                        var event = parser.eventType
                        while (event != XmlPullParser.END_DOCUMENT) {
                            if (event == XmlPullParser.START_TAG && parser.name == "t") out.append(parser.nextText())
                            if (event == XmlPullParser.END_TAG && parser.name == "p") out.append("\n")
                            event = parser.eventType
                            if (event != XmlPullParser.END_DOCUMENT) event = parser.next()
                        }
                        return out.toString()
                    }
                    zip.closeEntry(); entry = zip.nextEntry
                }
            }
        }
        return "DOCX text part not found"
    }
    return resolver.openInputStream(uri)?.bufferedReader(Charsets.UTF_8)?.use { it.readText() } ?: ""
}

@OptIn(UnstableApi::class)
@Composable
fun VideoPreview(uri: Uri) {
    val context = LocalContext.current
    val player = remember(uri) { ExoPlayer.Builder(context).build().apply { setMediaItem(MediaItem.fromUri(uri)); prepare() } }
    val lifecycleOwner = LocalLifecycleOwner.current
    DisposableEffect(player, lifecycleOwner) {
        val observer = LifecycleEventObserver { _, event -> if (event == Lifecycle.Event.ON_PAUSE) player.pause() }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose { lifecycleOwner.lifecycle.removeObserver(observer); player.release() }
    }
    AndroidView(factory = { ctx -> PlayerView(ctx).apply { this.player = player } }, modifier = Modifier.fillMaxWidth().height(220.dp))
}
