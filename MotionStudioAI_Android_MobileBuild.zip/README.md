# Motion Studio AI Android starter — revised

This is a starter Android Studio project, not a completed video editor or APK.

## Included now
- Android Compose app shell
- Android document picker for video/audio/images/text/SRT/DOCX
- persistent read access to picked files where provider supports it
- Media3 video playback preview
- SRT/TXT text read + preview dialog
- basic DOCX text extraction from `word/document.xml`
- export resolution UI presets (480p/720p/1080p selection only; not rendering yet)
- no internet permission requested; import and preview are local

## Still to implement
- actual timeline with trimming and multiple tracks
- Media3 Transformer export pipeline and encoding presets
- audio mixing, fades and voice ducking
- subtitle overlay burn-in and SRT export
- motion graphics templates/animation compositor
- render queue, progress, review and save/share flow
- optional downloadable offline speech/LLM models

## Build requirements
Android Studio, JDK 17, Android SDK Platform 35, Gradle compatible with Android Gradle Plugin 8.7.3.
Open the project folder, sync Gradle, then Build > Build APK(s). The first sync needs internet to download Gradle/dependencies. After dependencies are cached, parts of development/build can work offline.

## Honest status
No APK was built or device-tested in this environment (Android SDK/build tools are unavailable here). The code has been revised for the missing lifecycle Compose dependency and added text/DOCX parsing, but compile validation must happen in Android Studio.

## Build from a phone using GitHub Actions (cloud build)
1. Create a GitHub repository and upload these project files.
2. Open the repository's **Actions** tab.
3. Choose **Build Android APK**, then **Run workflow**.
4. Wait for the workflow to finish successfully.
5. Open the completed run, download the `MotionStudioAI-debug-apk` artifact, unzip it, and install `app-debug.apk` (allow installs from that browser/file manager if Android prompts).
This cloud build requires internet and a GitHub account. The workflow is included, but has not been executed here.
